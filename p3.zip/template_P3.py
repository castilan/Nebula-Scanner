"""
Program: CS115 Project 3
Author: Your name here.
Description: TBD
"""
import sys
import time
from helper_graphics import *
from os.path import join




def draw_menu(win, w, h):
    '''Creates and draws a menu of buttons.
    
    Args:
        win (GraphWin): The window where buttons will be drawn.
        w (int): Width of the graphical window
        h (int): Height of the graphical window
    
    Returns:
        list: a list L, where L[i] is the i-th button (Rectangle object).

    '''
    pass


def wait_for_menu(win, buttons):
    '''Waits for a click, detects the clicked button and returns its index.
    
    Args:
        win (GraphWin): The window where the user would click.
        buttons (list): A list, where buttons[i] is the i-th button (Rectangle object).
    
    Returns:
        int: a value between 0 and len(buttons)-1, indicating the 
             index of the button that was clicked.
    '''
    pass




def main():

    #dirname = input("Name of directory you want to open: ")
    dirname = 'nebula_small'

    file_list = os.listdir(dirname)
    print("List of images:", file_list)

    # Get first noisy image
    inputImageFilename = file_list[0]
    fullname = join(dirname, inputImageFilename)
    print('Full path of first file:', fullname)

    #Create an Image object using fullname. Store it in variable img
    img = Image(Point(0, 0), fullname)

    #Get width and height of image
    w = img.getWidth()
    h = img.getHeight()

    #Set anchor of image to its center point
    img.setAnchor(Point(w // 2, h // 2))

    try:
        #TODO: Display the image in graphical window
        pass

    except GraphicsError:
        print("Please close the window properly next time")

main()
